export { NgModuleTemplate } from './ng-module/index.js';
export { NgStandaloneTemplate } from './ng-standalone/index.js';
export { NgEnvTemplate } from './ng-env/index.js';
export { NgAppTemplate } from './ng-app/index.js';

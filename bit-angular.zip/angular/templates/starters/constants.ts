export const DEFAULT_SCOPE_NAME = 'my-org.my-scope';
export const FORKED_ENV_NAME = 'envs/my-angular-env';

---
labels: ['angular', 'typescript']
description: 'An Angular application'
---

# Demo app documentation

Run your application with `bit run demo-app`.

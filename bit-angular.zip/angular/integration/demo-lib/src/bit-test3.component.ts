import { Component } from '@angular/core';

@Component({
  selector: 'bit-test3',
  standalone: true,
  template: `
      <p>
      bit-test 3 standalone works!
      </p>
        `
})
export class BitTest3Component {}

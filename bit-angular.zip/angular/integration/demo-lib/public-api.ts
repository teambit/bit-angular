/**
 * Entry point for this Angular library, do not move or rename this file.
 */
export * from './src/bit-test.component';
export * from './src/bit-test2.component';
export * from './src/bit-test3.component';
export * from './src/bit-test.module';

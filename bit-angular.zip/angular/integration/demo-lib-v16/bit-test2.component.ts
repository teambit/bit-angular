import { Component } from '@angular/core';

@Component({
  selector: 'bit-test2-v16',
  template: `
      <p>
      bit-test 2 works as well!
      </p>
        `
})
export class BitTest2Component {}

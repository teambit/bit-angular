import { Component } from '@angular/core';

@Component({
  selector: 'bit-test3-v19',
  standalone: true,
  template: `
      <p>
      bit-test 3 standalone works!
      </p>
        `
})
export class BitTest3Component {}

import React from 'react';
import { ComponentsDocumentation } from './index';

export const BasicNg = () => (
  <ComponentsDocumentation />
);

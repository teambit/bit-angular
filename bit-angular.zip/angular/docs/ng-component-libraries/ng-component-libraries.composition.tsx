import React from 'react';
import NgComponentLibraries from './index';
    
export const PreviewMDX = () => <NgComponentLibraries />
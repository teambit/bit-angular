export { default as ngComponentLibraries, default } from './ng-component-libraries.mdx';

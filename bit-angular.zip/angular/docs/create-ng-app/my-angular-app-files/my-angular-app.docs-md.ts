export default `---
labels: ['angular', 'typescript', 'apps']
description: 'An Angular application.'
---

# MyAngularApp documentation

Run your application with \`bit run my-angular-app\`.`;

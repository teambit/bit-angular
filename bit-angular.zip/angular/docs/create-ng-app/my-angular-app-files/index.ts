export default `export * from './my-angular-app.ng-app';`;

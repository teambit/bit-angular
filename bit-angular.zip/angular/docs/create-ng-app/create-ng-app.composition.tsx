import React from 'react';
import { CreateNgApp } from './index';

export const BasicNg = () => (
  <CreateNgApp />
);

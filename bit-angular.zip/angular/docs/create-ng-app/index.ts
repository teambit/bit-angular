export { default as CreateNgApp, default } from './create-ng-app.mdx';

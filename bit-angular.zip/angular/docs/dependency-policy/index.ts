export { default as DependencyPolicy, default } from './dependency-policy.mdx';

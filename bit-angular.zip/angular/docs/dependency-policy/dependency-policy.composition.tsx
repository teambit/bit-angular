import React from 'react';
import { DependencyPolicy } from './index';

export const BasicNg = () => (
  <DependencyPolicy />
);

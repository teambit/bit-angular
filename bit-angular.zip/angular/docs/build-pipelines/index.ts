export { default as BuildPipelines } from './build-pipelines.mdx';
export { default as BuildPipelinesTemplate, default } from './build-pipelines-template.mdx';
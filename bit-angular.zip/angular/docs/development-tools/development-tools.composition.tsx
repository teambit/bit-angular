import React from 'react';
import { DevelopmentTools } from './index';

export const BasicNg = () => (
  <DevelopmentTools />
);

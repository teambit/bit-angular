import React from 'react';
import { AppBuild } from './index';

export const BasicNg = () => (
  <AppBuild />
);

export { default as NgDesignOverview, default } from './ng-design-overview.mdx';

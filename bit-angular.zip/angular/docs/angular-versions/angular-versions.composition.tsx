import React from 'react';
import { AngularVersions } from './index';

export const BasicAngularVersions = () => (
  <AngularVersions />
);

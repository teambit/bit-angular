export { default as AngularVersions, default } from './angular-versions.mdx';

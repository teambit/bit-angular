import React from 'react';
import { BitAngularIntroduction } from './index';

export const BasicNg = () => (
  <BitAngularIntroduction />
);

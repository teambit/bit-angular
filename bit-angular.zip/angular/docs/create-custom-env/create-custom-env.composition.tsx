import React from 'react';
import { CreateCustomEnv } from './index';

export const BasicNg = () => (
  <CreateCustomEnv />
);

import React from 'react';
import { AppDeploy } from './index';

export const BasicNg = () => (
  <AppDeploy />
);

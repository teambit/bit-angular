export { angularEnvDocsData } from './angular-env-docs-data';

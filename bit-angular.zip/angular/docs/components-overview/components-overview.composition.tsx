import React from 'react';
import { ComponentsOverview } from './index';

export const BasicNg = () => (
  <ComponentsOverview />
);

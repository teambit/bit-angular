export { default as ComponentLibs, default } from './component-libs.mdx';

import React from 'react';
import { ComponentLibs } from './index';

export const BasicNg = () => (
  <ComponentLibs />
);

export { default as WorkspaceStarters, default } from './workspace-starters.mdx';

import React from 'react';
import { WorkspaceStarters } from './index';

export const BasicNg = () => (
  <WorkspaceStarters />
);

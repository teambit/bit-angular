export { default as NgTheming, default } from './ng-theming.mdx';

import React from 'react';
import { NgTheming } from './index';

export const BasicNg = () => (
  <NgTheming />
);

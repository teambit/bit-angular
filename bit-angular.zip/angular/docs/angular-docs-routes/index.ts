export { angularRouteBase, learnAngular } from './angular-docs-routes';

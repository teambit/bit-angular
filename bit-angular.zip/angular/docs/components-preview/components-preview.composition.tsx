import React from 'react';
import { ComponentsPreview } from './index';

export const BasicNg = () => (
  <ComponentsPreview />
);

import React from 'react';
import { BaseComponents } from './index';

export const BasicNg = () => (
  <BaseComponents />
);

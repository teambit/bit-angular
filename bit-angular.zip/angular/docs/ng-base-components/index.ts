export { default as BaseComponents, default } from './base-components.mdx';

export { default as ComponentGenerators, default } from './component-generators.mdx';

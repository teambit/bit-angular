import React from 'react';
import { ComponentGenerators } from './index';

export const BasicNg = () => (
  <ComponentGenerators />
);

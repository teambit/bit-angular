---
description: A bit compiler using ng-packagr for Angular libraries.
labels: ['angular', 'ng-packagr']
---

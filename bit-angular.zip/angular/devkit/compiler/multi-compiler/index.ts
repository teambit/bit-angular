export { NgMultiCompiler } from './ng-multi-compiler.js';
export { NgMultiCompilerTask } from './ng-multi-compiler.task.js';

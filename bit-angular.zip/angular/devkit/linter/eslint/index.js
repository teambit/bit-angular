module.exports = require('./eslintrc');

---
description: ESLint configurations for the Angular env
labels: ['eslint', 'configurations', 'angular', 'env']
---

The default [Angular ESLint](https://github.com/angular-eslint/angular-eslint) configuration for the Angular environment ([@bitdev.angular/angular-env](https://bit.cloud/bitdev/angular/angular-env)).

Review the configuration [here](bit-angular-eslint.ts).

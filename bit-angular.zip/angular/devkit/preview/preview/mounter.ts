/* eslint-disable import/no-unresolved */
import { createMounter } from '@bitdev/angular.dev-services.preview.mounter';

export default createMounter();

export { ngBootstrap, ngToCustomElements } from './loader.js';
export { ngToReact, customElementsToReact } from './loader-react.js';
export type { NgBootstrapOptions } from './loader.js';

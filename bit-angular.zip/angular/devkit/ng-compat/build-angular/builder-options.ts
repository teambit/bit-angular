/* eslint-disable */
export type { BrowserBuilderOptions, DevServerBuilderOptions } from '@angular-devkit/build-angular';

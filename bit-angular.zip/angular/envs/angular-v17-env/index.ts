export { AngularV17Env, ngEnvOptions } from './angular-v17-env.bit-env.js';

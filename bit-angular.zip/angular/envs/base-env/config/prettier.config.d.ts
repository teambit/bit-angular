declare const prettierConfig: any;
export default prettierConfig;
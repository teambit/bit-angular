---
description: A generic Bit development environment for Angular Components
labels: ['angular', 'aspect', 'extension']
---

**Do not use this directly.** If you want to add Angular support to your workspace, install the development environment for a specific Angular version.
For example: [@bitdev.angular/angular-env](https://bit.cloud/bitdev/angular/angular-env).

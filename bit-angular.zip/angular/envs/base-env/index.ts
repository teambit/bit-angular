export { AngularBaseEnv } from './angular-base-env.bit-env.js';
export type { AngularEnvInterface } from './angular-env.interface.js';

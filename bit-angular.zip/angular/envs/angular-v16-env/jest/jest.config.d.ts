import { Config } from 'jest';

declare const config: Config;
export default config;
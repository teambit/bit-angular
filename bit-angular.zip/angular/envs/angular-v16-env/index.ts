export { AngularV16Env, ngEnvOptions } from './angular-v16-env.bit-env.js';

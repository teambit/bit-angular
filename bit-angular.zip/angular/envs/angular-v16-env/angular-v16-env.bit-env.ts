import { AngularEnvOptions } from '@bitdev/angular.dev-services.common';
import { AngularBaseEnv } from '@bitdev/angular.envs.base-env';
import { createRequire } from 'node:module';
import { webpackConfigFactory } from './webpack-config.factory.js';

const req = createRequire(import.meta.url);

export const ngEnvOptions: AngularEnvOptions = {
  useAngularElementsPreview: false,
  // angularElementsModulePath: require.resolve('@angular/elements'),
  jestModulePath: req.resolve('jest'),
  ngPackagrModulePath: req.resolve('ng-packagr'),
  webpackConfigFactory,
  webpackDevServerModulePath: req.resolve('webpack-dev-server'),
  // resolving to the webpack used by angular devkit to avoid multiple instances of webpack
  // otherwise, if we use a different version, it would break
  webpackModulePath: req.resolve('webpack', { paths: [req.resolve('@angular-devkit/build-angular')] }),
  // devServer: 'webpack',
};

export class AngularV16Env extends AngularBaseEnv {
  /**
   * name of the environment. used for friendly mentions across bit.
   */
  name = 'angular-v16-env';

  angularVersion = 16;

  ngEnvOptions: AngularEnvOptions = ngEnvOptions;

  /* Jest config. Learn how to replace tester - https://bit.dev/reference/testing/set-up-tester */
  protected jestConfigPath = req.resolve('./jest/jest.config.cjs');
}

export default new AngularV16Env();

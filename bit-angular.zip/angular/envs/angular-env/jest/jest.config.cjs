const jestConfig = require('@bitdev/angular.envs.angular-v19-env/jest/jest.config.cjs');

module.exports = jestConfig;

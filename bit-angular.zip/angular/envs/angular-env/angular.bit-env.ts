import { AngularV19Env } from '@bitdev/angular.envs.angular-v19-env';

export class AngularEnv extends AngularV19Env {
  name = 'Angular';
}

export default new AngularEnv();

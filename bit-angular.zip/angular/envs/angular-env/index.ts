export { AngularEnv } from './angular.bit-env.js';
export { ngEnvOptions } from '@bitdev/angular.envs.angular-v19-env';

export { AngularV18Env, ngEnvOptions } from './angular-v18-env.bit-env.js';

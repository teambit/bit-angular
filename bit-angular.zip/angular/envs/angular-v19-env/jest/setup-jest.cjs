const { setupZoneTestEnv } = require('jest-preset-angular/setup-env/zone');

setupZoneTestEnv();

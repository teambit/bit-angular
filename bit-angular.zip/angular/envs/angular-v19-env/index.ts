export { AngularV19Env, ngEnvOptions } from './angular-v19-env.bit-env.js';

export { MyAngularV16Env, MyAngularV16Env as default } from './my-angular-v16-env.bit-env.js';

export { MyAngularV17Env, MyAngularV17Env as default } from './my-angular-v17-env.bit-env.js';
// @ts-ignore
export { default as jestConfig } from './config/jest.config.cjs';
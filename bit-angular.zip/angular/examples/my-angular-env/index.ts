export { MyAngularEnv, MyAngularEnv as default } from './my-angular-env.bit-env.js';

/**
 * @see https://bit.dev/reference/prettier/prettier-config
 */
const prettierConfig = require('@bitdev/angular.envs.base-env/config/prettier.config.cjs');

module.exports = {
  ...prettierConfig,
};

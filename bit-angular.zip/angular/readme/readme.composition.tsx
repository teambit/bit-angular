import React from 'react';
import Readme from './index';

export const PreviewMDX = () => <Readme />
